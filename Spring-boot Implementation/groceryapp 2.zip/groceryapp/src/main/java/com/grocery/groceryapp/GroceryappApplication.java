package com.grocery.groceryapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GroceryappApplication {

	public static void main(String[] args) {
		SpringApplication.run(GroceryappApplication.class, args);
	}

}
